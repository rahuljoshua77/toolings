import os,sys
import whois

def main():
    menu = int(input("Menu: \n1. Port Scanner\n2. SQLi Deteector \n3. Whois Lookup\nChoose menu (1/2/3): "))
    
    if menu == 1:
        os.system('cls' if os.name == 'nt' else 'clear')

        print("""
        Scanner Syntax and Examples
        --------------------------

        1. python3 scanner.py <ip>
        Example: python3 scanner.py 192.168.0.1

        2. python3 scanner.py <ip> <verbose>
        Example: python3 scanner.py 192.168.0.1 -v

        3. python3 scanner.py <ip> <port_start> <port_end>
        Example: python3 scanner.py 192.168.0.1 150 1333

        4. python3 scanner.py <ip> <port_start> <port_end> <verbose>
        Example: python3 scanner.py 192.168.0.1 150 1333 -v
        """)
        cmd = input("Input your command: ")
        
        os.system(f'cd ./src/port-scanner-main && {cmd}')
    elif menu == 2:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("""
        usage: sqlidetector.py [-h] -f FILE [-w WORKERS] [-p PROXY] [-t TIMEOUT] [-o OUTPUT]
        A simple tool to detect SQL errors
        optional arguments:
        -h, --help            show this help message and exit]
        -f FILE, --file FILE  [File of the urls]
        -w WORKERS, --workers [WORKERS Number of threads]
        -p PROXY, --proxy [PROXY Proxy host]
        -t TIMEOUT, --timeout [TIMEOUT Connection timeout]
        -o OUTPUT, --output [OUTPUT [Output file]

        example: 
        python3 sqlidetector.py -f urls.txt -w 50 -o output.txt -t 10 
        """)
        cmd = input("Input your command: ")
        os.system(f'cd ./src/SQLiDetector-main && {cmd}')
        
    elif menu == 3:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("Whois lookup")
        domain = input("Domain target: ")
        
        ress  = whois.whois(domain)
        print(ress)
        with open(f'result-{domain}.txt','a') as f: f.write(f'{ress}\n')
main()