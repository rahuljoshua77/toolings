## [0.8.1](https://github.com/thecyberworld/port-scanner/compare/v0.7.0...v0.8.1) (2023-01-09)


### Bug Fixes

* datetime written as dt ([#33](https://github.com/thecyberworld/port-scanner/issues/33)) ([71d3877](https://github.com/thecyberworld/port-scanner/commit/71d387794f9345f96b554bdfabc5e83da8f9ecd6))



# [0.7.0](https://github.com/thecyberworld/port-scanner/compare/v0.6.0...v0.7.0) (2022-07-22)


### Features

* Dockerized ([#25](https://github.com/thecyberworld/port-scanner/issues/25)) ([2ff5530](https://github.com/thecyberworld/port-scanner/commit/2ff553075eb7289472b201df7371f1d158a1a9b0))



# [0.6.0](https://github.com/thecyberworld/port-scanner/compare/v0.5.0...v0.6.0) (2022-07-22)


### Features

* Dockerized ([#24](https://github.com/thecyberworld/port-scanner/issues/24)) ([e6292c1](https://github.com/thecyberworld/port-scanner/commit/e6292c1caa42b3e73ce26716048ec5096031e411))



# [0.5.0](https://github.com/thecyberworld/port-scanner/compare/v0.4.0...v0.5.0) (2022-07-21)


### Features

* Open source ([#23](https://github.com/thecyberworld/port-scanner/issues/23)) ([08bf330](https://github.com/thecyberworld/port-scanner/commit/08bf3303eff2ab74b4bc95f3f27db22c72210402))



# [0.4.0](https://github.com/thecyberworld/port-scanner/compare/v0.3.0...v0.4.0) (2022-07-17)


### Features

* output results ([#22](https://github.com/thecyberworld/port-scanner/issues/22)) ([166f209](https://github.com/thecyberworld/port-scanner/commit/166f209acfd393a9bf8bb3ff7bafe2e4b732678f))



